angular.module("buzzbook")
.controller('LoginCtrl', ['$scope', '$rootScope', '$location', 'AuthenticationService',
    function ($scope, $rootScope, $location, AuthenticationService) {
        $scope.userDetails = {};
        $scope.data = {};
       // AuthenticationService.ClearCredentials();
        $scope.login = function (dataLogin) {
            console.log("login Working");
            $scope.dataLoading = true;
            AuthenticationService.Login(dataLogin.username, dataLogin.password, function (response) {
                if (response.success) {
                  //  AuthenticationService.SetCredentials(response.result[0].user_city, response.result[0].user_name);
                    $location.path('/home');                    
                    //$scope.userDetails = response.result[0];                                       
                    // console.log("LOGIN user: " + $scope.data.username + " - PW: " + $scope.data.password);
                } else {
                    $scope.error = response.message;
                    $scope.dataLoading = false;
                }
            });
        }
}])
.controller('homeCtrl', ['$scope', '$rootScope', '$location', 'AuthenticationService',
    function ($scope, $rootScope, $location, AuthenticationService) {
        $scope.authdata = "read";       
}])
.controller('otpSuccessCntrl', ['$scope', '$rootScope', '$location', 'AuthenticationService',
    function ($scope, $rootScope, $location, AuthenticationService) {
      //  $scope.authdata = "read";       
}])
.controller('otpCntrl', ['$scope', '$rootScope', '$location', 'AuthenticationService',
    function ($scope, $rootScope, $location, AuthenticationService) {
       // $scope.authdata = "read";
        $scope.otp = function (dataOTP) {
            console.log($rootScope.authData);
            $scope.dataLoading = true;
            AuthenticationService.OTP(dataOTP.otp, $rootScope.authData, function (response) {
                //console.log("LOGIN user: " + dataRegister.firstname + " - PW: " + dataRegister.lastname);
                if (response.success) {
                    //AuthenticationService.SetAccesssToken(response.access_token);
                    $location.path('/registerSuccess');
                    // console.log("LOGIN user: " + $scope.data.username + " - PW: " + $scope.data.password);
                } else {
                    //console.log("Register Working");
                    $scope.error = response.message;
                    $scope.dataLoading = false;
                }
            });
        };
        $scope.resendOTP = function (dataOTP) {
            console.log($rootScope.authData);
            $scope.dataLoading = true;
            AuthenticationService.OTP_Resend($rootScope.authData, function (response) {
                //console.log("LOGIN user: " + dataRegister.firstname + " - PW: " + dataRegister.lastname);
                if (response.success) {
                    //AuthenticationService.SetAccesssToken(response.access_token);                    
                   // $location.path('/registerSuccess');
                    // console.log("LOGIN user: " + $scope.data.username + " - PW: " + $scope.data.password);
                } else {
                    //console.log("Register Working");
                    $scope.error = response.message;
                    $scope.dataLoading = false;
                }
            });
        };
}])
.controller('RegisterCntrl', ['$scope', '$rootScope', '$location', 'AuthenticationService',
    function ($scope, $rootScope, $location, AuthenticationService) {        
    $scope.data = {};
    AuthenticationService.ClearCredentials();
    $scope.register = function (dataRegister) {        
        $scope.dataLoading = true;
        AuthenticationService.Register(dataRegister.firstname, dataRegister.lastname, dataRegister.email, dataRegister.phone_number, dataRegister.password, dataRegister.dob, dataRegister.gender, function (response) {
            //console.log("LOGIN user: " + dataRegister.firstname + " - PW: " + dataRegister.lastname);
            if (response.success) {
                //console.log(response.access_token);
                AuthenticationService.SetAccesssToken(response.access_token);
                $location.path('/registerOTP');                 
                // console.log("LOGIN user: " + $scope.data.username + " - PW: " + $scope.data.password);
            } else {
                //console.log("Register Working");
                $scope.error = response.message;
                $scope.dataLoading = false;
            }
        });

    }
}])