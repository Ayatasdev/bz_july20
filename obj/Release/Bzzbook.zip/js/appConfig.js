angular.module('config')
  .value('app.config', {
      basePath: '/' // Set your base path here
  });