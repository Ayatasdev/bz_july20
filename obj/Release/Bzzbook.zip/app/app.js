angular.module("buzzbook", ["ionic"])
.run(function ($ionicPlatform) {
    $ionicPlatform.ready(function () {
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
       // if (window.cordova && window.cordova.plugins.Keyboard) {
           // cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
       // }
        if (window.StatusBar) {
            StatusBar.styleDefault();
        }
    });
})

.config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider
    .state('login', {
        url: '/login',       
        templateUrl: 'templates/logintab.html',
        //controller: 'LoginCtrl'
    })
    .state('login.home', {
        url: "/home",
        views: {
            'home-tab': {
                templateUrl: "templates/initTabContent/loginScreen.html",
                controller: 'LoginCtrl'
            }
        }
    })
    .state('login.register', {
        url: "/register",
        views: {
            'register-tab': {
                templateUrl: "templates/initTabContent/register.html",
                controller: 'RegisterCntrl'
            }
        }
    })
    .state('login.contact', {
        url: "/contact",
        views: {
            'contact-tab': {
                templateUrl: "templates/initTabContent/contact.html",
                //controller: 'HomeTabCtrl'
            }
        }
    })

    .state('home',{
        url: '/home',
        templateUrl: 'templates/homePage.html',
            controller: 'homeCtrl'
    })
      .state('registration', {
          url: '/registerOTP',
          templateUrl: 'templates/registrationOTP.html',
          controller: 'otpCntrl'
      })
     .state('registrationSuccess', {
         url: '/registerSuccess',
         templateUrl: 'templates/regSuccess.html',
         controller: 'otpSuccessCntrl'
     })
    $urlRouterProvider.otherwise('/login');
   // $urlRouterProvider.otherwise('/registerOTP');
})
